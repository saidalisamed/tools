uWSGI NGINX deployment on Ubuntu
--------------------------------
# Upload your application folder 'example-python-flask' to /var/www/html/

sudo mkdir /etc/uwsgi
sudo mkdir /var/log/uwsgi
sudo chown -R www-data:adm /var/log/uwsgi
sudo vim /etc/uwsgi/example-python-flask.ini
# add the following

[uwsgi]
socket = /tmp/example-python-flask.sock
master = true
enable-threads = true
processes = 1
chdir= /var/www/html/example-python-flask
module=run:app
virtualenv = /var/www/html/example-python-flask/flask
uid =  www-data
gid = www-data
logto = /var/log/uwsgi/example-python-flask.log


sudo vim /etc/init/example-python-flask.conf
# add the following

# file: /etc/init/example-python-flask.conf
description example-python-flask uWSGI server

start on runlevel [2345]
stop on runlevel [!2345]
respawn
exec /var/www/html/example-python-flask/flask/bin/uwsgi -c /etc/uwsgi/example-python-flask.ini


sudo start example-python-flask
sudo vim /etc/nginx/sites-available/example-python-flask.conf
# add the following

server {
    listen 80;

    access_log /var/log/nginx/.log;
    error_log /var/log/nginx/.log error;

    location /static/ { alias /var/www/html/example-python-flask/app/static/; }
    location /api/static/ { alias /var/www/html/example-python-flask/app/api/static/; }

    location / {
        include uwsgi_params;
        uwsgi_pass unix:/tmp/example-python-flask.sock;
    }
}


sudo ln -s /etc/nginx/sites-available/example-python-flask.conf /etc/nginx/sites-enabled
sudo service nginx restart

