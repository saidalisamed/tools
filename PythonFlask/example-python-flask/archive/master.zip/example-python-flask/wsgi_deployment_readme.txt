

- Run following commands to install configure apache web server. (Ubuntu)

# Install apache
sudo apt-get install apache2

# Install modules
sudo apt-get install libapache2-mod-fcgid
sudo apt-get install libapache2-mod-wsgi


# Enable apache modules rewrite and wsgi
sudo a2enmod rewrite
sudo a2enmod wsgi


- Run following commands to set up flask virtualenv if development workstation is non-linux. (Ubuntu)

# Prepare for flask virtualenv
sudo apt-get install python-virtualenv
sudo apt-get install libmysqld-dev
sudo apt-get install python-dev

# Install flask in virtualenv
cd /var/www/html/
virtualenv example-python-flask/flask
example-python-flask/flask/bin/pip install flask
example-python-flask/flask/bin/pip install flask-sqlalchemy
example-python-flask/flask/bin/pip install flask-restful
example-python-flask/flask/bin/pip install mysql-python
example-python-flask/flask/bin/pip install flup

# Sample Apache wsgi virtual host configuration. Remove the .htaccess file if using wsgi
<VirtualHost *:80>
    #ServerName example.com
    #ServerAlias www.example.com
    ServerAdmin webmaster@localhost
    ErrorLog /var/log/apache2/error.log
    CustomLog /var/log/apache2/access.log combined

    WSGIDaemonProcess example-python-flask user=www-data group=www-data threads=50
    WSGIScriptAlias / /var/www/html/example-python-flask/run.wsgi

    Alias "/static/" "/var/www/html/example-python-flask/app/static/"
    <Directory "/var/www/html/example-python-flask/app/static/">
      Order allow,deny
      Allow from all
    </Directory>

    <Directory /var/www/html/example-python-flask>
        WSGIProcessGroup example-python-flask
        WSGIApplicationGroup %{GLOBAL}
        Order deny,allow
        Allow from all
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>
</VirtualHost>
