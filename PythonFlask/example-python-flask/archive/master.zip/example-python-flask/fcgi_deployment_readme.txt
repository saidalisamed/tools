

- Run following commands to install configure apache web server. (Ubuntu)

# Install apache
sudo apt-get install apache2

# Install modules
sudo apt-get install libapache2-mod-fcgid
sudo apt-get install libapache2-mod-wsgi


# Enable apache modules rewrite and fcgid
sudo a2enmod rewrite
sudo a2enmod fcgid

# Apache virtualhost configuration

<VirtualHost *:80>
    #ServerName example.com
    #ServerAlias www.example.com
    ServerAdmin webmaster@localhost
    ErrorLog /var/log/apache2/error.log
    CustomLog /var/log/apache2/access.log combined
    DocumentRoot /var/www/html/example-python-flask

    <Directory /var/www/html/example-python-flask>
        Order deny,allow
        Allow from all
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>


- Run following commands to set up flask virtualenv if development workstation is non-linux. (Ubuntu)

# Prepare for flask virtualenv
sudo apt-get install python-virtualenv
sudo apt-get install libmysqld-dev
sudo apt-get install python-dev

# Install flask in virtualenv
cd /var/www/html/
virtualenv example-python-flask/flask
example-python-flask/flask/bin/pip install flask
example-python-flask/flask/bin/pip install flask-sqlalchemy
example-python-flask/flask/bin/pip install flask-restful
example-python-flask/flask/bin/pip install mysql-python
example-python-flask/flask/bin/pip install flup
