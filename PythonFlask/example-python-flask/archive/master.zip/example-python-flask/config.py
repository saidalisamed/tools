# configuration
DEBUG = False
SECRET_KEY = 'Run in interpreter for strong secret: import os;os.urandom(24)'
SQLALCHEMY_DATABASE_URI = 'mysql://username:password@localhost/database_name'
