from flask import render_template, flash
from app import app
from api.views import api_blueprint

# Register blueprints
app.register_blueprint(api_blueprint, url_prefix='/api')


@app.route('/')
def home():
    return render_template('home.html')


@app.errorhandler(404)
def page_not_found(e):
    flash('Sorry, nothing at this URL.')
    return render_template('home.html'), 404, e
