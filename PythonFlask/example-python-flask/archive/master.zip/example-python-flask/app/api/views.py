from flask import Blueprint
from flask_restful import Resource, Api

# Blueprint
api_blueprint = Blueprint('api_blueprint', __name__, template_folder='templates', static_folder='static')
api = Api(api_blueprint)


class Version(Resource):
    def get(self):
        return {'version': '1.0'}
api.add_resource(Version, '/version')


@api_blueprint.route('/')
def home():
    return 'API home'
